import React, { forwardRef, useImperativeHandle } from "react";
import {
  AgGridReact
} from "ag-grid-react";
import type {
  GridApi,
  ColumnApi,
  ColDef,
  CellEditingStoppedEvent,
  SelectionChangedEvent,
  IRowNode
} from "ag-grid-community";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { api, getErrorMessage } from "../api";

export type ResourceDto = {
  resource_group: string;
  is_constraint: boolean | null;
  capacity: number | null;
};

export type MasterGridConfig = {
  editable: Record<keyof ResourceDto, boolean>;
};

export type MasterGridHandle = {
  load: (groups: string[]) => Promise<void>;
  reload: () => Promise<void>;
  addRow: () => void;
  deleteSelected: () => Promise<void>;
  saveNew: () => Promise<void>;
  saveEdits: () => Promise<void>;
  cancelAll: () => void;
  clearFilters: () => void;
  getSelectionCount: () => number;
};

type Props = {
  onSelect: (resourceGroup: string | null) => void;
  canWrite?: boolean;
  config?: MasterGridConfig; // optional config from /api/grid-config/scheduled-resources-master
  className?: string;
};

const DEFAULT_CFG: MasterGridConfig = {
  editable: {
    resource_group: false,
    is_constraint: true,
    capacity: true
  }
};

const MasterGrid = forwardRef<MasterGridHandle, Props>(function MasterGrid(
  { onSelect, canWrite = true, config, className },
  ref
) {
  const cfg = config || DEFAULT_CFG;

  const gridRef = React.useRef<AgGridReact<ResourceDto>>(null);
  const gridApi = React.useRef<GridApi | null>(null);
  const colApi = React.useRef<ColumnApi | null>(null);

  const [rowData, setRowData] = React.useState<ResourceDto[]>([]);
  const [groups, setGroups] = React.useState<string[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState<
    Record<string, Partial<ResourceDto>>
  >({}); // id -> changed fields

  // track new rows (__isNew marked)
  const markPending = (id: string, key: keyof ResourceDto, value: any) => {
    setPending((prev) => ({
      ...prev,
      [id]: { ...(prev[id] || {}), [key]: value }
    }));
  };

  const fetchRows = React.useCallback(async (grps: string[]) => {
    if (!grps || grps.length === 0) {
      setRowData([]);
      setPending({});
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const url = `/api/resources?groups=${encodeURIComponent(grps.join(";"))}`;
      const res = await api.get<ResourceDto[]>(url);
      setRowData(res.data || []);
      setPending({});
      // ensure calendar is cleared until the user selects a single row
      onSelect(null);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, [onSelect]);

  // public API
  useImperativeHandle(ref, () => ({
    load: async (grps) => {
      setGroups(grps);
      await fetchRows(grps);
    },
    reload: async () => {
      await fetchRows(groups);
    },
    addRow: () => {
      if (!canWrite) return;
      const api = gridRef.current?.api;
      if (!api) return;
      const r: any = {
        resource_group: "",
        is_constraint: false,
        capacity: 0,
        __isNew: true,
        __requiredMissing: true
      };
      api.applyTransaction({ add: [r], addIndex: 0 });
      const rn = api.getDisplayedRowAtIndex(0);
      if (rn) {
        api.ensureIndexVisible(0);
        api.startEditingCell({ rowIndex: 0, colKey: "resource_group" });
      }
    },
    deleteSelected: async () => {
      if (!canWrite) return;
      const api = gridRef.current?.api;
      if (!api) return;
      const ids: string[] = [];
      api.getSelectedNodes().forEach((n) => {
        const d = n.data as any;
        if (d.__isNew) {
          // just remove locally
          api.applyTransaction({ remove: [d] });
        } else {
          ids.push(d.resource_group);
        }
      });
      if (ids.length === 0) return;
      setLoading(true);
      setError(null);
      try {
        await apiDeleteResources(ids);
        await fetchRows(groups);
      } catch (e) {
        setError(getErrorMessage(e));
      } finally {
        setLoading(false);
      }
    },
    saveNew: async () => {
      if (!canWrite) return;
      const apiGrid = gridRef.current?.api;
      if (!apiGrid) return;
      const newRows: ResourceDto[] = [];
      apiGrid.forEachNode((n) => {
        const r: any = n.data;
        if (r?.__isNew && r.resource_group) {
          newRows.push({
            resource_group: r.resource_group,
            is_constraint: !!r.is_constraint,
            capacity: r.capacity ?? 0
          });
        }
      });
      if (!newRows.length) return;
      setLoading(true);
      setError(null);
      try {
        for (const r of newRows) {
          await api.post("/api/resources", r);
        }
        await fetchRows(groups);
      } catch (e) {
        setError(getErrorMessage(e));
      } finally {
        setLoading(false);
      }
    },
    saveEdits: async () => {
      if (!canWrite) return;
      const payload = Object.entries(pending).map(([id, changes]) => ({
        id,
        changes
      }));
      if (!payload.length) return;
      setLoading(true);
      setError(null);
      try {
        await api.patch("/api/resources", payload);
        setPending({});
        await fetchRows(groups);
      } catch (e) {
        setError(getErrorMessage(e));
      } finally {
        setLoading(false);
      }
    },
    cancelAll: () => {
      // remove all new rows + discard pending
      const apiGrid = gridRef.current?.api;
      if (apiGrid) {
        const toRemove: any[] = [];
        apiGrid.forEachNode((n) => {
          const r: any = n.data;
          if (r?.__isNew) toRemove.push(r);
        });
        if (toRemove.length) apiGrid.applyTransaction({ remove: toRemove });
      }
      setPending({});
      // also stop any active editing
      gridApi.current?.stopEditing();
      // and refresh cells to remove "dirty" styling
      gridApi.current?.refreshCells({ force: true });
    },
    clearFilters: () => {
      gridApi.current?.setFilterModel(null);
      gridApi.current?.onFilterChanged();
    },
    getSelectionCount: () => {
      return gridRef.current?.api?.getSelectedNodes().length || 0;
    }
  }));

  const onGridReady = (e: any) => {
    gridApi.current = e.api;
    colApi.current = e.columnApi;
  };

  const onSelectionChanged = (e: SelectionChangedEvent) => {
    const nodes = e.api.getSelectedNodes();
    if (nodes.length === 1) {
      onSelect((nodes[0].data as ResourceDto).resource_group);
    } else {
      onSelect(null);
    }
  };

  const onCellEditingStopped = (e: CellEditingStoppedEvent<ResourceDto>) => {
    if (!canWrite) return;
    const row = e.data!;
    const field = e.colDef.field as keyof ResourceDto;
    if (!field) return;
    if ((row as any).__isNew && field === "resource_group") {
      // user typed key -> row is no longer "required missing"
      (row as any).__requiredMissing = !row.resource_group;
    }
    // only track editable fields
    if (cfg.editable[field]) {
      markPending(row.resource_group, field, row[field as keyof ResourceDto]);
    }
    // flash cell
    e.api.flashCells({ rowNodes: [e.node], columns: [e.column] });
  };

  // style for rows/cells: new/dirty markers
  const getRowClass = (p: any) => {
    const d = p.data as any;
    if (d?.__isNew) return "row-new";
    if (pending[d?.resource_group]) return "row-dirty";
    return "";
  };
  const getCellClass = (p: any) => {
    const d = p.data as any;
    const f = p.colDef.field as keyof ResourceDto;
    if (!f) return "";
    const dirty = pending[d?.resource_group]?.hasOwnProperty(f);
    const classes: string[] = [];
    if (dirty) classes.push("cell-dirty");
    if (d?.__isNew && f === "resource_group" && d.__requiredMissing)
      classes.push("required-missing");
    return classes.join(" ");
  };

  const colDefs = React.useMemo<ColDef<ResourceDto>[]>(() => {
    return [
      {
        headerName: "Resource group",
        field: "resource_group",
        editable: (p) => !!(p.data as any)?.__isNew && canWrite,
        width: 220,
        filter: true,
        cellClass: getCellClass
      },
      {
        headerName: "Constraint",
        field: "is_constraint",
        editable: canWrite && !!cfg.editable.is_constraint,
        width: 130,
        filter: true,
        cellEditor: "agCheckboxCellEditor",
        cellClass: getCellClass
      },
      {
        headerName: "Capacity",
        field: "capacity",
        editable: canWrite && !!cfg.editable.capacity,
        width: 120,
        filter: "agNumberColumnFilter",
        valueParser: (p) => {
          if (p.newValue === "" || p.newValue == null) return null;
          const n = Number(p.newValue);
          return Number.isNaN(n) ? p.oldValue : Math.round(n);
        },
        cellClass: getCellClass
      }
    ];
  }, [canWrite, cfg]);

  const defaultColDef = React.useMemo<ColDef>(() => {
    return {
      sortable: true,
      resizable: true,
      filter: true,
      flex: 1
    };
  }, []);

  return (
    <div className={className}>
      <div className="ag-theme-alpine modern-ag" style={{ height: "100%" }}>
        <AgGridReact<ResourceDto>
          theme="legacy"
          ref={gridRef as any}
          rowData={rowData}
          columnDefs={colDefs}
          defaultColDef={defaultColDef}
          animateRows
          rowSelection={{ mode: "multiRow" }}
          suppressRowClickSelection={false}
          onCellEditingStopped={onCellEditingStopped}
          onSelectionChanged={onSelectionChanged}
          onGridReady={onGridReady}
          getRowClass={getRowClass}
        />
      </div>

      {loading && (
        <div className="mt-2 text-xs text-slate-500">Working…</div>
      )}
      {error && (
        <div className="mt-2 text-sm text-rose-700 bg-rose-50 border border-rose-200 rounded px-3 py-1">
          {error}
        </div>
      )}
    </div>
  );
});

export default MasterGrid;

// ------------- helpers -------------
async function apiDeleteResources(ids: string[]) {
  return api.delete("/api/resources", { data: ids });
}
