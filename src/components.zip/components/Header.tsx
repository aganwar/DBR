import React from "react";

export default function Header() {
  return (
    <header className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b">
      {/* Full-width container (no centering), small side padding */}
      <div className="w-full px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src="/logo.svg" alt="DBR-AI" className="w-7 h-7" />
          <div>
            <div className="font-semibold text-slate-900 leading-none">DBR-AI</div>
            <div className="text-xs text-slate-500 leading-none">Scheduled Resources</div>
          </div>
        </div>

        <div className="text-xs text-slate-500 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          online
        </div>
      </div>
    </header>
  );
}
