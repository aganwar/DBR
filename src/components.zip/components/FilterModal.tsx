import React from "react";
import { api } from "../api";

type Props = {
  initialSelected: string[];
  onApply: (groups: string[]) => void;
  onClose: () => void;
};

export default function FilterDialog({ initialSelected, onApply, onClose }: Props) {
  const [loading, setLoading] = React.useState(true);
  const [allGroups, setAllGroups] = React.useState<string[]>([]);
  const [selected, setSelected] = React.useState<string[]>(initialSelected || []);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setError(null);
        const res = await api.get<string[]>("/api/resource-groups");
        if (!mounted) return;
        setAllGroups(res.data || []);
      } catch (e: any) {
        setError(e.message || String(e));
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  const toggle = (g: string) => {
    setSelected(prev => prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g]);
  };

  const allSelected = selected.length === allGroups.length && allGroups.length > 0;
  const toggleAll = () => setSelected(allSelected ? [] : [...allGroups]);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/20" onClick={onClose} />
      <div className="absolute left-1/2 top-20 -translate-x-1/2 w-[520px] rounded-2xl bg-white border shadow-xl overflow-hidden">
        <div className="px-4 py-3 border-b flex items-center justify-between">
          <div className="font-medium text-slate-800">Choose Resource Groups</div>
          <button className="btn-ghost text-sm" onClick={onClose}>Close</button>
        </div>
        <div className="p-4">
          {loading && <div className="text-sm text-slate-500">Loading…</div>}
          {error && <div className="text-sm text-rose-700 bg-rose-50 border border-rose-200 rounded px-3 py-1">{error}</div>}
          {!loading && !error && (
            <>
              <label className="flex items-center gap-2 mb-2 text-sm">
                <input type="checkbox" checked={allSelected} onChange={toggleAll} />
                <span>Select all</span>
              </label>
              <div className="max-h-[320px] overflow-auto rounded border">
                {allGroups.map(g => (
                  <label key={g} className="flex items-center gap-2 px-3 py-2 border-b last:border-b-0 text-sm">
                    <input type="checkbox" checked={selected.includes(g)} onChange={() => toggle(g)} />
                    <span>{g}</span>
                  </label>
                ))}
              </div>
            </>
          )}
        </div>
        <div className="px-4 py-3 border-t flex items-center justify-end gap-2">
          <button className="btn" onClick={() => setSelected([])}>Clear</button>
          <button className="btn-solid" onClick={() => onApply(selected)}>Apply</button>
        </div>
      </div>
    </div>
  );
}
