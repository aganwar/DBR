import React from "react";
import { AgGridReact } from "ag-grid-react";
import type { ColDef, GridApi, ColumnApi, CellValueChangedEvent } from "ag-grid-community";
import "ag-grid-community/styles/ag-grid.css";            // legacy CSS for theme="legacy"
import "ag-grid-community/styles/ag-theme-alpine.css";
import dayjs from "dayjs";
import { api } from "../api";
import type { GridConfig } from "../App";

type CalendarRow = {
  dates: string;                  // "yyyy-MM-dd"
  resource: string;
  capacity: number | null;
  is_off: boolean | null;         // read-only (db sets when capacity = 0 on save)
  is_customised: boolean | null;  // read-only (db sets true on save)
};

type Props = {
  height: number;
  resource: string | null;        // selected from master
  config: GridConfig | null;
  onSaved?: () => void;
};

type RangeKey = "thisweek" | "next7" | "thismonth" | "all";

export default function CalendarGrid({ height, resource, config, onSaved }: Props) {
  const gridRef = React.useRef<AgGridReact<CalendarRow>>(null);
  const apiRef = React.useRef<GridApi | null>(null);
  const colApiRef = React.useRef<ColumnApi | null>(null);

  const [rows, setRows] = React.useState<CalendarRow[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // local edits: { "2025-08-20": { capacity: 8 } }
  const [edits, setEdits] = React.useState<Record<string, Partial<CalendarRow>>>({});
  const [range, setRange] = React.useState<RangeKey>("thisweek");

  const readOnly = !!config?.readOnly;
  const canEditCapacity = !!config?.editableColumns?.includes("capacity") && !readOnly;

  // Compute from/to based on range
  const computeRange = React.useCallback((): { from?: string; to?: string } => {
    const today = dayjs().startOf("day");
    if (range === "all") return {};
    if (range === "thisweek") {
      const start = today.startOf("week").add(1, "day");   // Monday
      const end = start.add(6, "day");
      return { from: start.format("YYYY-MM-DD"), to: end.format("YYYY-MM-DD") };
    }
    if (range === "next7") {
      const end = today.add(6, "day");
      return { from: today.format("YYYY-MM-DD"), to: end.format("YYYY-MM-DD") };
    }
    // thismonth
    const mstart = today.startOf("month");
    const mend = today.endOf("month");
    return { from: mstart.format("YYYY-MM-DD"), to: mend.format("YYYY-MM-DD") };
  }, [range]);

  // Load data when resource or range changes
  const load = React.useCallback(async () => {
    setError(null);
    setEdits({});
    setRows([]);
    if (!resource) return;

    const { from, to } = computeRange();
    let url = `/api/calendar/${encodeURIComponent(resource)}`;
    const qs: string[] = [];
    if (from) qs.push(`from=${from}`);
    if (to) qs.push(`to=${to}`);
    if (qs.length) url += `?${qs.join("&")}`;

    setLoading(true);
    try {
      const res = await api.get<CalendarRow[]>(url);
      setRows(res.data ?? []);
    } catch (e: any) {
      setError(e?.message || "Failed to load calendar");
    } finally {
      setLoading(false);
    }
  }, [resource, computeRange]);

  React.useEffect(() => { load(); }, [load]);

  // clear local edits (Cancel)
  const cancelAll = () => {
    setEdits({});
    load();
  };

  // save only edited cells
  const saveAll = async () => {
    if (!resource) return;
    if (!Object.keys(edits).length) return;

    setLoading(true); setError(null);
    try {
      await api.patch(`/api/calendar/${encodeURIComponent(resource)}`, {
        changesByDate: edits,
      });
      setEdits({});
      await load();
      onSaved?.();
    } catch (e: any) {
      setError(e?.message || "Save failed");
    } finally {
      setLoading(false);
    }
  };

  // User changed capacity in grid
  const onCellValueChanged = (e: CellValueChangedEvent<CalendarRow>) => {
    if (e.colDef.field !== "capacity") return;
    const ymd = e.data?.dates;
    if (!ymd) return;

    let newVal: number | null = null;
    if (e.newValue === "" || e.newValue == null) newVal = null;
    else {
      const parsed = Number(
        String(e.newValue).replace(",", ".") // simple locale normalization
      );
      if (!Number.isFinite(parsed) || parsed < 0) {
        // revert
        e.node.setDataValue("capacity", e.oldValue);
        return;
      }
      newVal = Math.round(parsed);
    }

    setEdits(prev => ({ ...prev, [ymd]: { ...(prev[ymd] || {}), capacity: newVal } }));
    // flash only this one
    e.api.flashCells({ rowNodes: [e.node], columns: [e.column] });
  };

  // Grid ready
  const onGridReady = (p: any) => {
    apiRef.current = p.api;
    colApiRef.current = p.columnApi;
  };

  // Col defs
  const colDefs = React.useMemo<ColDef<CalendarRow>[]>(() => [
    {
      headerName: "Date",
      field: "dates",
      filter: true,
      sortable: true,
      width: 140,
      editable: false,
    },
    {
      headerName: "Resource",
      field: "resource",
      filter: true,
      sortable: true,
      width: 160,
      editable: false,
    },
    {
      headerName: "Capacity (hrs)",
      field: "capacity",
      filter: "agNumberColumnFilter",
      sortable: true,
      width: 150,
      editable: canEditCapacity,
      // show green dot on edited capacity
      cellClass: (p) => edits[p.data?.dates || ""]?.hasOwnProperty("capacity") ? "cell-dirty" : "",
      valueSetter: (p) => {
        // let ag-grid update value; we’ll record via onCellValueChanged (normalizes)
        // just accept and return true
        return true;
      },
    },
    {
      headerName: "Off",
      field: "is_off",
      width: 90,
      editable: false,
      cellRenderer: p => p.value ? "✓" : "",
    },
    {
      headerName: "Customised",
      field: "is_customised",
      width: 120,
      editable: false,
      cellRenderer: p => p.value ? "✓" : "",
    },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [canEditCapacity, edits]);

  const defaultColDef = React.useMemo<ColDef>(() => ({
    resizable: true,
    sortable: true,
    filter: true,
    flex: 1,
  }), []);

  // Range buttons
  const RangeButtons = (
    <div className="flex items-center gap-2">
      <span className="text-xs text-slate-500 mr-1">Range:</span>
      <button
        className={`px-2 py-1 text-xs rounded border ${range === "thisweek" ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}
        onClick={() => setRange("thisweek")}
      >
        This week
      </button>
      <button
        className={`px-2 py-1 text-xs rounded border ${range === "next7" ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}
        onClick={() => setRange("next7")}
      >
        Next 7 days
      </button>
      <button
        className={`px-2 py-1 text-xs rounded border ${range === "thismonth" ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}
        onClick={() => setRange("thismonth")}
      >
        This month
      </button>
      <button
        className={`px-2 py-1 text-xs rounded border ${range === "all" ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}
        onClick={() => setRange("all")}
      >
        All
      </button>
    </div>
  );

  return (
    <div className="flex flex-col gap-2">
      {/* Toolbar (Save / Cancel + Range) */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={saveAll}
            disabled={!Object.keys(edits).length || !resource || readOnly}
            className="px-3 py-1.5 text-sm rounded border hover:bg-slate-50 disabled:opacity-40"
            title="Save changes"
          >
            Save Changes
          </button>
          <button
            onClick={cancelAll}
            disabled={!Object.keys(edits).length}
            className="px-3 py-1.5 text-sm rounded border hover:bg-slate-50 disabled:opacity-40"
            title="Cancel unsaved edits"
          >
            Cancel
          </button>
        </div>
        <div>{RangeButtons}</div>
      </div>

      {/* Grid */}
      {!resource ? (
        <div className="text-sm text-slate-500 px-2 py-3">Select a single resource to view its calendar.</div>
      ) : (
        <>
          {error && <div className="text-rose-700 bg-rose-50 border border-rose-200 px-3 py-2 rounded">{error}</div>}
          <div className="ag-theme-alpine modern-ag" style={{ height }}>
            <AgGridReact<CalendarRow>
              theme="legacy"
              ref={gridRef as any}
              rowData={rows}
              columnDefs={colDefs}
              defaultColDef={defaultColDef}
              animateRows
              suppressRowClickSelection={false}
              rowSelection={{ mode: "singleRow" }}
              onGridReady={onGridReady}
              onCellValueChanged={onCellValueChanged}
            />
          </div>
          {loading && <div className="text-xs text-slate-500 mt-1">Working…</div>}
        </>
      )}
    </div>
  );
}
