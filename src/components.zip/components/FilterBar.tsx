import React from "react";

type Props = {
  defaultGroups: string[];
  onApply: (groups: string[]) => void;
};

export default function FilterBar({ defaultGroups, onApply }: Props) {
  const [text, setText] = React.useState(defaultGroups.join(";"));

  const parse = (v: string) =>
    v
      .split(/[;\n,]+/g)
      .map(s => s.trim())
      .filter(Boolean);

  const apply = () => onApply(parse(text));

  const clear = () => {
    setText("");
    onApply([]);
  };

  return (
    <div className="rounded-2xl shadow-sm border bg-white overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b bg-gradient-to-b from-white to-slate-50">
        <div className="font-medium text-slate-800">Filter</div>
        <div className="text-xs text-slate-500">Enter resource groups (semicolon/comma/new line)</div>
      </div>
      <div className="p-4 flex flex-col gap-3">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="24-28375;24-28425;Default"
          className="w-full h-20 rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 ring-slate-900/10"
        />
        <div className="flex gap-2">
          <button onClick={apply} className="px-3 py-1.5 rounded bg-slate-900 text-white hover:bg-slate-800">Load</button>
          <button onClick={clear} className="px-3 py-1.5 rounded border hover:bg-slate-50">Clear</button>
        </div>
      </div>
    </div>
  );
}
