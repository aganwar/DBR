import React from "react";

type Props = { open: boolean; message: string };

export default function Toast({ open, message }: Props) {
  return (
    <div
      className={
        "fixed top-4 right-4 z-[9999] transition-opacity duration-200 " +
        (open ? "opacity-100" : "opacity-0 pointer-events-none")
      }
      aria-live="polite"
    >
      <div className="rounded-lg bg-slate-900 text-white text-sm px-3 py-2 shadow-lg">
        {message}
      </div>
    </div>
  );
}
