import React from "react";

type Props = {
  onFilter: () => void;
  onAdd: () => void;
  onDelete: () => void;
  onSave: () => void;
  onCancel: () => void;
};

const IconBtn: React.FC<React.PropsWithChildren<{ title: string; onClick: () => void; disabled?: boolean }>> = ({ title, onClick, disabled, children }) => (
  <button
    title={title}
    onClick={onClick}
    disabled={disabled}
    className="w-11 h-11 grid place-items-center rounded-xl border text-slate-600 bg-white/90 hover:bg-white disabled:opacity-40 shadow-sm"
  >
    {children}
  </button>
);

export default function ControlRail({ onFilter, onAdd, onDelete, onSave, onCancel }: Props) {
  return (
    <div className="absolute -left-16 top-1 z-20">
      <div className="flex flex-col gap-3 p-3 rounded-2xl bg-white border shadow-sm">
        <IconBtn title="Filter (F)" onClick={onFilter}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M3 5h18l-7 8v6l-4-2v-4L3 5z" stroke="currentColor" strokeWidth="1.6"/></svg>
        </IconBtn>
        <IconBtn title="Add" onClick={onAdd}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="1.6"/></svg>
        </IconBtn>
        <IconBtn title="Delete selected" onClick={onDelete}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 7h12M9 7V5h6v2M7 7l1 12h8l1-12" stroke="currentColor" strokeWidth="1.6"/></svg>
        </IconBtn>

        {/* Save/Cancel row */}
        <div className="mt-1 grid gap-2">
          <button className="btn text-xs" onClick={onSave}>Save</button>
          <button className="btn text-xs" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
